﻿using System;
using UIKit;

namespace SAILIIOS1
{
    public class SAILI_Repository
    {
        public SAILI_Repository()
        {
        }


    }
}
